var coffee = [
{
  id: 0,
  name: "Capuccino",
  short_description: " Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  long_description: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos." ,
  price: 2,
  image: "http://placehold.it/300x300",
  who_drinks_it: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  how_to_drink: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  gallery: ["http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300"]
},
{
  id: 1,
  name: "Latté",
  short_description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit.",
  long_description: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos." ,
  price: 2,
  image: "http://placehold.it/300x300",
  who_drinks_it: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  how_to_drink: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  gallery: ["http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300"]
},
{
  id: 2,
  name: "Flate White",
  short_description: " Ut enim ea dolorum quam quisquam beatae doloremqun.",
  long_description: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos." ,
  price: 2,
  image: "http://placehold.it/300x300",
  who_drinks_it: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  how_to_drink: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  gallery: ["http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300"]
},
{
  id: 3,
  name: "Piccolo",
  short_description: " Ut enim ea dolorum quam quisquam beatae doloremqun.",
  long_description: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos." ,
  price: 2,
  image: "http://placehold.it/300x300",
  who_drinks_it: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  how_to_drink: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  gallery: ["http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300"]
},
{
  id: 4,
  name: "Machiato",
  short_description: " Ut enim ea dolorum quam quisquam beatae doloremqun.",
  long_description: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos." ,
  price: 1,
  image: "http://placehold.it/300x300",
  who_drinks_it: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  how_to_drink: "Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos. Velit reiciendis voluptas assumenda doloremque temporibus nisi quos.",
  gallery: ["http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300", "http://placehold.it/300x300"]
}
  ];


 // Look at the ember: http://jsbin.com/izijal/9/edit
var express = require('express');





var app = express();



// configure Express
app.configure(function() {
  app.use(express.cookieParser('some secret'));
  app.use(express.bodyParser());
  app.use(express.methodOverride());
  app.use(app.router);
  app.use(express.static(__dirname + '/static'));
});


app.get('/api/v1/coffees', function (req, res) {
  coffee_list = coffee.map(function(x, i){
   return { id: x.id, name: x.name, short_description: x.short_description, price: x.price};
  })
  // res.writeHead(200, { 'Content-Type': 'application/json' });
  res.json({'coffees': coffee_list});
});

app.get("/api/v1/coffees/:id", function(req, res){
 res.json({coffees: coffee.filter(function(a, i) {
   return +req.params.id === +a.id;
 })})
})


app.listen(4242, function() {
  console.log('Express server listening on port 4242');
});


